/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';

const loadingMessages = [
  "Planting the seeds of your video...",
  "Watering the pixels...",
  "Harvesting nature's colors...",
  "Photosynthesizing the frames...",
  "Consulting with the digital gardener...",
  "Rendering the morning dew...",
  "Applying natural lighting...",
  "This can take a few minutes, grow strong...",
  "Adding a touch of organic magic...",
  "Composing the symphony of nature...",
  "Polishing the fresh produce...",
  "Ensuring 100% natural generation...",
  "Checking for digital pests...",
  "Ripening the animation...",
  "Enhancing the zest...",
  "Don't worry, the pixels are chemical-free.",
  "Harvesting fresh ideas...",
  "Praying to the Gemini star...",
  "Starting a draft for your nature documentary..."
];

const LoadingIndicator: React.FC = () => {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setMessageIndex((prevIndex) => (prevIndex + 1) % loadingMessages.length);
    }, 3000); // Change message every 3 seconds

    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-12 bg-white/5 rounded-lg border border-white/10 backdrop-blur-sm">
      <div className="w-16 h-16 border-4 border-t-transparent border-green-400 rounded-full animate-spin"></div>
      <h2 className="text-2xl font-semibold mt-8 text-green-100">Generating Your Video</h2>
      <p className="mt-2 text-green-200/70 text-center transition-opacity duration-500">
        {loadingMessages[messageIndex]}
      </p>
    </div>
  );
};

export default LoadingIndicator;
